export class Article {
  _articleid: string;
  _parentId: string;
  _type: string;
  _classes: string;
  title: string;
  displayTitle: string;
 
  body: string;
  instruction: string;
  _childInfo:any;
}
