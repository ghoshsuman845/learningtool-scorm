export class Page {
    _pageid: string;
    _type:string;
    _parentId: string;
    title: string;
    displayTitle: string;
    body: string;
    pageBody: string;
    instruction: string;
    btnlinkText: string;
    duration:string;
    _pageLevelProgressEnabled:boolean;
    _childInfo:any;
}
