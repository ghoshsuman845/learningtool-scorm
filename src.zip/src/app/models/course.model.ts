export class Course {
    _courseid: string;
    _type: string;
    title: string;
    displayTitle: string;
    description: string;
    body: string;
    tags: string;
    lockType: string;
    customCSS: any;
    _childInfo:any;
        
        
}
