export class Components {
    _componentid: string;
    _parentId :string;
    _type: string;
    _component: string;
    _classes:string;
    _layout:string;
    title:string;
    displayTitle:string;
    body:string;
    instruction:string;
    _pageLevelProgressEnabled:boolean;


}
