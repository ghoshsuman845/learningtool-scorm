import { Components } from './components.model';

describe('Components', () => {
  it('should create an instance', () => {
    expect(new Components()).toBeTruthy();
  });
});
