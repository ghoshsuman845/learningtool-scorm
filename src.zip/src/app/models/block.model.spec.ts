import { Block } from './block.model';

describe('Block', () => {
  it('should create an instance', () => {
    expect(new Block()).toBeTruthy();
  });
});
