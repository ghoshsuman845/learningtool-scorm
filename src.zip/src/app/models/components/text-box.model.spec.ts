import { TextBox } from './text-box.model';

describe('TextBox', () => {
  it('should create an instance', () => {
    expect(new TextBox()).toBeTruthy();
  });
});
