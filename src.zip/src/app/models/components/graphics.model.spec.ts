import { Graphics } from './graphics.model';

describe('Graphics', () => {
  it('should create an instance', () => {
    expect(new Graphics()).toBeTruthy();
  });
});
