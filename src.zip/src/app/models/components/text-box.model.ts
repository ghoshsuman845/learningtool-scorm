export class TextBox {
    title: string;
    dtitle: string;
   body: string;
   _type: string;
    _parentId: string;
}
