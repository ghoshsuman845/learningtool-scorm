export class Graphics {
    

    _graphicsid: string;
    _parentId: string;
    _type: string;
    title: string;
    displayTitle: string;
    body: string;
    instruction:string;
    graphics_url: string;
 
   
}
