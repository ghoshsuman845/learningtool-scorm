export class Block {
  _blockid: string;
  _parentId: string;
  _classes: string;
  _type: string;
  title: string;
  displayTitle: string;
  body: string;
  _trackingId: number;
  instruction:string;
 _childInfo:any;
}
